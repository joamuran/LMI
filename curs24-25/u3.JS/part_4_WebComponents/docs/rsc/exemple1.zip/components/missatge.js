class MissatgeBenvinguda extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        const nom = this.getAttribute('nom') || 'Usuari';
        this.shadowRoot.innerHTML = `<h2>Hola, ${nom}!</h2>`;
    }
}

customElements.define('missatge-benvinguda', MissatgeBenvinguda);